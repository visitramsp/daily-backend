# Dayly — Backend

REST API using **Node.js, Express, MongoDB / Mongoose, Zod, Helmet, CORS, express-rate-limit and Morgan**.

## Requirements

- Node.js 20+
- MongoDB local server or MongoDB Atlas cluster

## Start

```bash
npm install
```

Copy `.env.example` to `.env` and configure:

```env
PORT=5000
MONGODB_URI=mongodb://127.0.0.1:27017/dayly
CLIENT_ORIGIN=http://localhost:5173
NODE_ENV=development
```

```bash
npm run dev
```

Run tests: `npm test`. Production: `npm start`.

## Structure

```text
src/
├── config/          database connection
├── controllers/     HTTP handlers (thin)
├── middleware/      error handling
├── models/          Task Mongoose schema
├── repositories/    database access
├── routes/          Express routes
├── services/        task business rules and queries
├── utils/           Zod schemas, week utilities
├── app.js           Express app and middleware
└── server.js        database/bootstrap/shutdown
tests/               unit tests
```

## API endpoints

| Method | Route | Purpose |
| --- | --- | --- |
| GET | `/api/health` | API health |
| GET | `/api/tasks` | List tasks |
| GET | `/api/tasks/:id` | Single task |
| POST | `/api/tasks` | Create |
| PATCH | `/api/tasks/:id` | Update |
| DELETE | `/api/tasks/:id` | Delete |

List query params: `search`, `status`, `priority`, `from`, `to`, `page`, `limit`.

Example POST body:

```json
{
  "title": "Review assignment",
  "description": "Verify all task features",
  "dueAt": "2026-11-13T12:30:00.000Z",
  "priority": "high",
  "status": "in_progress"
}
```

Status values are `in_progress` and `completed`. Priority values are `low`, `medium` and `high`. Dates are timezone-aware ISO strings. All endpoints return JSON except successful DELETE (204).

## Deployment

Configure `MONGODB_URI` from MongoDB Atlas and `CLIENT_ORIGIN` as your frontend's exact origin. Deploy on Render/Railway/etc. with `npm install` / `npm start`. This demo does not include authentication; it uses a shared task collection.
